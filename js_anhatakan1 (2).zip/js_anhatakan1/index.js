

const obj = {
    name: "John",
    age: 30,
    city: "New York",
    country: "USA"
};
document.getElementById("countButton").addEventListener("click", function() {
    const count = Object.values(obj).length;

    document.getElementById("count").textContent = count;
});
